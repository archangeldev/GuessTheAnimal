﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using GuessTheAnimal.Data;
using GuessTheAnimal.Models;

namespace GuessTheAnimal.Controllers
{
    public class GamesController : Controller
    {
        private readonly GuessTheAnimalContext _context;
        
        public GamesController(GuessTheAnimalContext context)
        {
            _context = context;
        }

        public IActionResult Yes ()
        {
            switch (Game.CurrentProperty.ToString()) {

                case "Colour":
                    Game.Animals.RemoveAll(a => a.Colour != Game.CurrentPropertyValue);
                    break;
                case "Possession":
                    Game.Animals.RemoveAll(a => a.Possession != Game.CurrentPropertyValue);
                    break;
                case "Vocalization":
                    Game.Animals.RemoveAll(a => a.Vocalization != Game.CurrentPropertyValue);
                    break;
                default:
                    break;
            }
            return Index();
        }

        public IActionResult No()
        {

            switch (Game.CurrentProperty.ToString())
            {

                case "Colour":
                    Game.Animals.RemoveAll(a => a.Colour == Game.CurrentPropertyValue);
                    break;
                case "Possession":
                    Game.Animals.RemoveAll(a => a.Possession == Game.CurrentPropertyValue);
                    break;
                case "Vocalization":
                    Game.Animals.RemoveAll(a => a.Vocalization == Game.CurrentPropertyValue);
                    break;
                default:
                    break;
            }
            return Index();
        }

        public IActionResult PlayAgain()
        {
            // refresh the current repository
            Game.Animals.Clear();
            Game.TimesRun = 0;
            return Index();
        }

        public IActionResult Index()
        {
            Game.TimesRun += 1;  // check if first run

            if (Game.TimesRun == 1) { 
                Game.PopulateData(_context);
            }

            // get distinct colors from list
            Game.colours = Game.Animals.Select(a => a.Colour).Distinct();
            foreach (string c in Game.colours)
            {
                if (Game.colours.Count() < 2)
                    break;
                ViewBag.Question = "Is it " + c + "?";
                Game.CurrentProperty = "Colour";
                Game.CurrentPropertyValue = c;
                return View("Index", Game.Animals);
            }
          
            // get possessions
            Game.possessions = Game.Animals.Select(a => a.Possession).Distinct();
            foreach (string p in Game.possessions)
            {
                if (Game.possessions.Count() < 2)
                    break;
                ViewBag.Question = "Does it have " + p + "?";
                Game.CurrentProperty = "Possession";
                Game.CurrentPropertyValue = p;
                return View("Index", Game.Animals);
            }

            // get vocalization
            Game.vocalizations = Game.Animals.Select(a => a.Vocalization).Distinct();
            foreach (string v in Game.vocalizations)
            {
                if (Game.vocalizations.Count() < 2)
                    break;
                ViewBag.Question = "Does it " + v + "?";
                Game.CurrentProperty = "Vocalization";
                Game.CurrentPropertyValue = v;
                return View("Index", Game.Animals);
            }

            return View("Index", Game.Animals);
        }

    }
}
