﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using GuessTheAnimal.Models;

namespace GuessTheAnimal.Data
{
    public class GuessTheAnimalContext : DbContext
    {
        public GuessTheAnimalContext(DbContextOptions<GuessTheAnimalContext> options) : base(options)
        {

        }

        public DbSet<Animal> Animals { get; set; }

        //public DbSet<GuessTheAnimal.Models.Game> Game { get; set; }

    }
}
