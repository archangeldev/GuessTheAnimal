﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.Collections;

namespace GuessTheAnimal.Models
{
    public class Animal
    {
        public int ID { get; set; }
        [Required]
        public string Name { get; set; }
        [Required]
        public string Possession { get; set; }
        [Required]
        public string Vocalization { get; set; }
        [Required]
        public string Colour { get; set; }

    }
}
