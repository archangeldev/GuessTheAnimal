﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using GuessTheAnimal.Models;

namespace GuessTheAnimal.Data
{
    public static class DbInitializer
    {
        public static void Initialize(GuessTheAnimalContext context)
        {
            context.Database.EnsureCreated();

            if (context.Animals.Any())
            {
                return;  // database has been seeded with data
            }

            var animals = new Animal[]
            {
                new Animal{Name="Elephant", Possession="a trunk", Vocalization="trumpet", Colour="grey"},
                new Animal{Name="Lion", Possession="a mane", Vocalization="roar", Colour="yellow"},
                new Animal{Name="Cat", Possession="whiskers", Vocalization="meow", Colour="black"},
                new Animal{Name="Pig", Possession="a snout", Vocalization="oink", Colour="pink"},
                new Animal{Name="Dog", Possession="a snout", Vocalization="bark", Colour="white"},
                new Animal{Name="Bird", Possession="wings", Vocalization="chirp", Colour="green"},
                new Animal{Name="Bat", Possession="wings", Vocalization="shriek", Colour="black"},
                new Animal{Name="Snake", Possession="scales", Vocalization="hiss", Colour="green"},
                new Animal{Name="Duck", Possession="a bill", Vocalization="quack", Colour="orange"},
                new Animal{Name="Rhinoceros", Possession="a tusk", Vocalization="roar", Colour="grey"},
                new Animal{Name="Boar", Possession="a tusk", Vocalization="roar", Colour="grey"},
                new Animal{Name="Puma", Possession="whiskers", Vocalization="roar", Colour="black"}
            };

            foreach (Animal a in animals)
            {
                context.Animals.Add(a);
            }
            context.SaveChanges();

        }
    }
}
