﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using GuessTheAnimal.Data;

namespace GuessTheAnimal.Models
{
    public static class Game 
    {
    public static int ID { get; set; }
    public static int TimesRun { get; set; }
    public static string CurrentProperty { get; set; }
    public static string CurrentPropertyValue { get; set; }
    public static bool CurrentResponse { get; set; }

    public static IEnumerable<string> colours { get; set; }
    public static IEnumerable<string> possessions { get; set; }
    public static IEnumerable<string> vocalizations { get; set; }

    public static List<Animal> Animals = new List<Animal>();

    public static void PopulateData(GuessTheAnimalContext context)
        {
            foreach (Animal a in context.Animals)
            {
                Animals.Add(a);
            }

        }
    }
}
